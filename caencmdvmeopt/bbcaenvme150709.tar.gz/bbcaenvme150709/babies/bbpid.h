int mkpid(char *name);
int rmpid(char *name);
int chkpid(char *name);
int killpid(char *name);
int pidof(char *name, int *pids);
int killpidof(char *name);
int chkpidof(char *name);
int dirtoname(char *path, char *name);
