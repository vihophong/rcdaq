/* Header for V1190 Multihit TDC */

void v1190_intlevel(unsigned int maddr, short level);
void v1190_tdcfull(unsigned int maddr, short fl);
void v1190_clear(unsigned int maddr);
int v1190_segdata(unsigned int maddr);
int v1190_dmasegdata(unsigned int maddr, int cnt);


/* Register */
#define V1190_OUTBUFF         0x0000
#define V1190_SOFT_CLEAR      0x1016
#define V1190_ALMOST_FULL     0x1022
#define V1190_INTLEVEL        0x100a
#define V1190_CTRL_REG        0x1000

/* Bit */
#define V1190_SOFT_CLEAR_BIT  1     

#define V1190_TYPE_MASK_S          0xf800
#define V1190_GLOBAL_HEADER_BIT_S  0x4000
#define V1190_TDC_HEADER_BIT_S     0x0800
#define V1190_TDC_DATA_BIT_S       0x0000
#define V1190_TDC_TRAILER_BIT_S    0x1800
#define V1190_TDC_ERROR_BIT_S      0x2000
#define V1190_GLOBAL_TRAILER_BIT_S 0x8000

#define V1190_TYPE_MASK          0xf8000000
#define V1190_GLOBAL_HEADER_BIT  0x40000000
#define V1190_TDC_HEADER_BIT     0x08000000
#define V1190_TDC_DATA_BIT       0x00000000
#define V1190_TDC_TRAILER_BIT    0x18000000
#define V1190_TDC_ERROR_BIT      0x20000000
#define V1190_GLOBAL_TRAILER_BIT 0x80000000
